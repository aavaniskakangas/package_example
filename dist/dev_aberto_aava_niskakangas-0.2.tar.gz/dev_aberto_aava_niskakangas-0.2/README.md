# dev_aberto package

https://github.com/Insper/open-dev/tree/master/docs/lessons/05-python-packaging

pip install -i https://test.pypi.org/simple/ dev-aberto-Aava-Niskakangas==0.1