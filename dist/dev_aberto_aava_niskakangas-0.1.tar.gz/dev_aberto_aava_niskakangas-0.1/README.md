# dev_aberto package

https://github.com/Insper/open-dev/tree/master/docs/lessons/05-python-packaging
